<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MainController;
use App\Http\Controllers\AdminController;
use App\Models\Order;


// Kiosk / POS page
Route::get('/', [MainController::class, 'index'])->name('dashboard');

//Menus
Route::post('/menus/add', [MainController::class, 'addMenu'])->name('menus.add');
Route::post('/menus/delete/{id}', [MainController::class, 'deleteMenu'])->name('menus.delete');

//Orders (walk-in only)
Route::post('/orders/add', [MainController::class, 'addOrder'])->name('orders.add');
Route::post('/orders/delete/{id}', [MainController::class, 'deleteOrder'])->name('orders.delete');

Route::get('/admin/login', [AdminController::class, 'showLogin'])->name('admin.login');
Route::post('/admin/login', [AdminController::class, 'login'])->name('admin.login.submit');

Route::middleware('admin.auth')->group(function () {
    Route::get('/admin/dashboard', [AdminController::class, 'dashboard'])->name('admin.dashboard');
    Route::post('/admin/logout', [AdminController::class, 'logout'])->name('admin.logout');
});




Route::post('/orders/update/{id}', [MainController::class, 'updateOrder'])->name('orders.update');

// Update order items
Route::post('/orders/update/{id}', [MainController::class, 'updateOrder'])->name('orders.update');
    Route::get('/api/order/{id}', function ($id) {
    $order = Order::with('orderItems.menu')->find($id);

    if (!$order) {
        return response()->json(['items' => []]);
    }

    $items = $order->orderItems->map(function ($i) {
    
        $menuName  = $i->menu->item_name ?? 'Unknown Item';
        $menuPrice = isset($i->menu) && is_numeric($i->menu->price) ? (float)$i->menu->price : 0.0;

        return [
            'order_item_id' => $i->order_item_id,
            'menu_id'       => $i->menu_id,
            'name'          => $menuName,
            'price'         => $menuPrice,   
            'quantity'      => (int)$i->quantity,
            'notes'         => $i->notes ?? '',
        ];
    });

    return response()->json(['items' => $items]);
});
